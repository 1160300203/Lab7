import React, { Component } from 'react';
import $ from 'jquery';
class CommodityPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            commodities: [],
            filterText: '',
            showOutOfStockCommodity: true,
            newCommodityName: '',
            newCommodityCategory: '',
            newCommodityStatus: ''
        };
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
        this.handleButtonClick = this.handleButtonClick.bind(this);
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleCategoryChange = this.handleCategoryChange.bind(this);
        this.handleStatusChange = this.handleStatusChange.bind(this);
        this.handleAddFormSubmit = this.handleAddFormSubmit.bind(this);
    }
    handleFilterTextChange(filterText) {
        this.setState({
            filterText: filterText
        });
    }
    handleButtonClick() {
        this.setState({
            showOutOfStockCommodity: !this.state.showOutOfStockCommodity
        })
    }
    handleNameChange(name) {
        this.setState({
            newCommodityName: name
        })
    }
    handleCategoryChange(category) {
        this.setState({
            newCommodityCategory: category
        })
    }
    handleStatusChange(status) {
        this.setState({
            newCommodityStatus: status
        })
    }
    handleAddFormSubmit(e) {
        alert("Add ("+this.state.newCommodityName + ", "+
            this.state.newCommodityCategory + ", " + this.state.newCommodityStatus + ") to the form");
        $.post("http://localhost:3001/users/addcommodity",
            {
                "category" : this.state.newCommodityCategory,
                "name" : this.state.newCommodityName,
                "status" : this.state.newCommodityStatus
            },
            function(data, status){
                if (data.msg ===''){
                    let newcommodities=this.state.commodities;
                    newcommodities.push({
                        "category" : this.state.newCommodityCategory,
                        "name" : this.state.newCommodityName,
                        "status" : this.state.newCommodityStatus
                    });
                    this.setState({
                        commodities: newcommodities,
                        newCommodityName: '',
                        newCommodityCategory: '',
                        newCommodityStatus: ''
                    });
                } else
                    alert(data.msg);
            }.bind(this)
        );
        e.preventDefault();
    }
    componentDidMount() {
        this.loadCommodities();
    }
    loadCommodities() {
        $.ajax({
            url: "http://localhost:3001/users/commodities",
            dataType: 'json',
            cache: false,
            success: function(data) {
                this.setState({ commodities: data });
            }.bind(this),
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
    }
    render() {
        return (
            <div>
            <SearchBar filterText={this.state.filterText} onFilterTextChange={this.handleFilterTextChange}/>
            <CommodityTable commodities={this.state.commodities} filterText={this.state.filterText} showOutOfStockCommodity={this.state.showOutOfStockCommodity} />
            <ShowHideButton showOutOfStockCommodity={this.state.showOutOfStockCommodity} onButtonClick={this.handleButtonClick}/>
            <AddCommodityForm newCommodityName={this.state.newCommodityName} newCommodityCategory={this.state.newCommodityCategory} newCommodityStatus={this.state.newCommodityStatus}
             newCommodityNameOnChange={this.handleNameChange} newCommodityCategoryOnChange={this.handleCategoryChange} newCommodityStatusOnChange={this.handleStatusChange}
             handleAddFormSubmit={this.handleAddFormSubmit}/></div>
        );
    }
}

class SearchBar extends Component {
    constructor(props) {
        super(props);
        this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
    }
    handleFilterTextChange(e) {
        this.props.onFilterTextChange(e.target.value);
    }
    render() {
        return (
            <form>
            <input
        type="text"
        placeholder="Search..."
        value={this.props.filterText}
        onChange={this.handleFilterTextChange}
        />
        </form>
    );
    }
}

class CommodityTable extends Component {
    render() {
        const filterText = this.props.filterText;
        const showOutOfStockCommodity = this.props.showOutOfStockCommodity;

        var rows = this.props.commodities.map((commodity) => {
            if (commodity.name.indexOf(filterText) === -1) {
                return null;
            }
            if (showOutOfStockCommodity || commodity.status === "in stock") {
                return (
                    <CommodityRow commodity={commodity} key={commodity.name} />
            );
            }
            return null;
        });
        return (
            <table>
            <thead>
            <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Status</th>
            </tr>
            </thead>
            <tbody>{rows}</tbody>
            </table>
    );
    }
}

class CommodityRow extends Component {
    render() {
        const commodity = this.props.commodity;
        return (
            <tr>
            <td>{commodity.name}</td>
            <td>{commodity.category}</td>
            <td>{commodity.status}</td>
            </tr>
        );
    }
}

class ShowHideButton extends Component {
    constructor(props) {
        super(props);
        this.handleButtonClick = this.handleButtonClick.bind(this);
    }
    handleButtonClick() {
        this.props.onButtonClick();
    }
    render() {return (
        <button onClick={this.handleButtonClick}>
        {this.props.showOutOfStockCommodity ? 'Hide Out-of-Stock Commodity' : 'Show Out-of-Stock Commodity'}
        </button>
        );
    }
}

class AddCommodityForm extends Component{
    constructor(props){
        super(props);
        this.handleCommodityName = this.handleCommodityName.bind(this);
        this.handleCommodityCategory = this.handleCommodityCategory.bind(this);;
        this.handleCommodityStatus = this.handleCommodityStatus.bind(this);
        this.handleAddFormSubmit = this.handleAddFormSubmit.bind(this);
    }

    handleCommodityName(event){
        return this.props.newCommodityNameOnChange(event.target.value);
    }

    handleCommodityCategory(event){
        return this.props.newCommodityCategoryOnChange(event.target.value);
    }

    handleCommodityStatus(event){
        console.log(event.target.value);
        return this.props.newCommodityStatusOnChange(event.target.value);
    }

    handleAddFormSubmit(event){
        this.props.handleAddFormSubmit(event);
    }

    render(){
        return (
            <form>
            <div>
            Name: <input type="text" value={this.props.newCommodityName} onChange={this.handleCommodityName}/>
            </div>
            <div>
            Category: <input type="text" value={this.props.newCommodityCategory} onChange={this.handleCommodityCategory}/>
            </div><div>Status:
            <select value={this.props.newCommodityStatus === "" ? "0" : this.props.newCommodityStatus} onChange={this.handleCommodityStatus}>
                <option value="0"></option>
                <option value="in stock">in stock</option>
                <option value="out of stock">out of stock</option>
            </select>
            </div>
            <button onClick={this.handleAddFormSubmit}>submit</button>
            </form>
        );
    }
}

export default CommodityPage;